package com.nuexpert.schd.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;

import com.nuexpert.schd.feed.GasPriceForcast;
import com.nuexpert.schd.feed.WeatherForcast;

public class StartupServlet extends HttpServlet implements Runnable{
	
Thread refreshData; 

	public void init() throws ServletException{ 
		   
		 refreshData=new Thread(this);
		 refreshData.setPriority(Thread.MIN_PRIORITY);
		 refreshData.start();
	}
	
	   @Override
	public void run() {
		   int i=1;
		   while(true){
		   System.out.println("----------  Refresh static data----------"+(i++));   
		   
		   try{

			   WeatherForcast.loadData();
			  
			   System.out.println("----------  load Weather data successfully ----------");   
		   }catch(Exception ex){
			   
			   System.out.println("----------"+ex);
		   }
		   try{
			  GasPriceForcast.loadData();
			  System.out.println("----------  load GAS data successfully ----------");  
 
		   }catch(Exception ex){
			   
			   System.out.println("----------"+ex);
		   }
		   try{
			   Thread.sleep(1000*60*60*3);
		   }catch(InterruptedException ignored){
			   //System.out.println("----------  Servlet Initialized successfully ----------");   
		   }
		   
		   
		   }
	
		
	}

	@Override
	public void service(ServletRequest arg0, ServletResponse arg1)
			throws ServletException, IOException {
		System.out.println("Start to load data");
		//super.service(arg0, arg1);
	}

}
