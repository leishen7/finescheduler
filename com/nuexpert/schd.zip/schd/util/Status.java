package com.nuexpert.schd.util;


public class Status {
	public static final String REQUESTED="requested";
	public static final String UPDATED="updated";
	public static final String CANCELLED="cancelled";
	public static final String CONFIRMED="confirmed";
	public static final String REJECTED="rejected";

}
